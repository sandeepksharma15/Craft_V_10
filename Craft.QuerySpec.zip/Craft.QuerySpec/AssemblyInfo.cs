using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Craft.QuerySpec.Tests")]
