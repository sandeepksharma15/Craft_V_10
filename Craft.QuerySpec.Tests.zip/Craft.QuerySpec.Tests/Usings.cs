global using KeyType = long;
